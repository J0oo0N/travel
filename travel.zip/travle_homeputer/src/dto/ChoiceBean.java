package dto;

public class ChoiceBean {
	
	private int choice_id;
	private int informataion_id;
	
	public int getChoice_id() {
		return choice_id;
	}
	public void setChoice_id(int choice_id) {
		this.choice_id = choice_id;
	}
	public int getInformataion_id() {
		return informataion_id;
	}
	public void setInformataion_id(int informataion_id) {
		this.informataion_id = informataion_id;
	}
	

}
