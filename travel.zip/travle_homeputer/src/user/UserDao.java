package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
	private Connection conn;
	private PreparedStatement pstm;
	private ResultSet rs;
	
	public UserDao() {
		try {
			String dbURL ="jdbc:oracle:thin:@localhost:1521:xe";
			String dbID = "travle_homeputer";
			String dbPassword = "1234";
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//로그인 시도
	public int login(String user_id, String user_pw) {
		String SQL = "SELECT user_pw FROM user_info WHERE user_id = ?";
			try {
				pstm = conn.prepareStatement(SQL);
				pstm.setString(1, user_id);
				rs = pstm.executeQuery();
				if(rs.next()) {
					if(rs.getString(1).equals(user_pw)) {
						return 1;//로그인 성공
					}else 
						return 0; //비밀번호 불일치
				}
				return -1; //아이디가 없다
			} catch(Exception e) {
				e.printStackTrace();
			}
			return -2; //데이터베이스 오류
	}//login end
	
	//회원가입 기능
	public int signUp(User user) {
		String SQL = "INSERT INTO user_info VALUES(?,?,?,?,?,?)";
		
		try { pstm = conn.prepareStatement(SQL);
				pstm.setString(1, user.getUser_id());
				pstm.setString(2, user.getUser_pw());
				pstm.setString(3, user.getUser_name());
				pstm.setString(4, user.getUser_birth());
				pstm.setString(5, user.getUser_tell());
				pstm.setString(6, user.getUser_email());
		}catch(Exception e) {
			e.printStackTrace();
		}
			return -1;//데이터베이스 오류
	}//signUp end

}
